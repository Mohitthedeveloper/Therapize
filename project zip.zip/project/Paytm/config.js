var PaytmConfig = {
    mid: "Kkatvd34334425459416",
    key: "fgkmv_RHsi6R@QXm",
    website: "WEBSTAGING",
  };
  module.exports.PaytmConfig = PaytmConfig;